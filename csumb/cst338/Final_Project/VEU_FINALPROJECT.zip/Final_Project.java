/*
 	Vanessa Ulloa
 	CST 338 - Final Project
 	+ Simple Student Registration System
 */

public class Final_Project 
{
	public static void main(String[] args)
	{		
		FPGUI projectMain = new FPGUI();
		projectMain.setVisible(true);
	}
}
